<?php
	$url="localhost";
	$username = "root";
	$password="";
	$db="it146";
	$id=$_POST["id"];
	$name=$_POST["name"];
	$con = mysqli_connect($url,$username,$password,$db);
	if(!$con)
	{
		die("Unable to connect".mysqli_connect_error());
	}
	$sql="update student set name='$name' where id=$id";
	if(mysqli_query($con,$sql))
	{
		echo("one row updated");
	}
	else
	{
		echo("no row updated".mysqli_error($con));
	}
	mysqli_close($con);
	?>