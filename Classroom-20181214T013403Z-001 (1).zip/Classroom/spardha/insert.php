<?php
	$url="localhost";
	$username = "root";
	$password="";
	$db="it146";
	$id=$_POST["id"];
	$name=$_POST["name"];
	$branch=$_POST["branch"];
	$con = mysqli_connect($url,$username,$password,$db);
	if(!$con)
	{
		die("Unable to connect".mysqli_connect_error());
	}
	$sql="insert into student values($id,'$name','$branch')";
	if(mysqli_query($con,$sql))
	{
		echo("one row inserted");
	}
	else
	{
		echo("no row inserted".mysqli_error($con));
	}
	mysqli_close($con);
	?>