<?php
if(isset($_COOKIE["user"]))
{
	echo("welcome".$_COOKIE["user"]); 
}
else
{
	echo("welcome guest");
}
?>