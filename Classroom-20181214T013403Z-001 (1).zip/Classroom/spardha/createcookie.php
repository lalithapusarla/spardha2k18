<?php
setcookie("user","sandeep",time()+30*24*60*60);
echo("cookie creatyed");
?>
