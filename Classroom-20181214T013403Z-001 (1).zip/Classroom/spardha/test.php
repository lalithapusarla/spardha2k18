 <html>
 <body>
 <?php
        //session_start();
		$url="localhost";
		$username = "root";
        $password="";
		$db="cps";
        //$Username=$_SESSION['myssession'];
		$Username = 160105146


        $con = mysqli_connect($url,$username,$password,$db);
	if(!$con)
	{
		die("Unable to connect".mysqli_connect_error());
	}

        mysqli_select_db($database);

        $sql = "SELECT * FROM registration WHERE id='$Username'";
        $result = mysqli_query ($sql) or die (mysql_error ());
        while ($row = mysql_fetch_array ($result)){

        ?>

        <form action="test.php" method="post">
            Name
            <input type="text" name="Firstname" value="<?php echo $row ['Firstname']; ?> " size=10>
            Username
            <input type="text" name="Id" value="<?php echo $row ['Id']; ?> " size=10>
            Password
            <input type="text" name="Password" value="<?php echo $row ['Password']; ?>" size=17>
            <input type="submit" name="submit" value="Update">
        </form>
        <?php
        }
        ?>
        </p>
    </body>
</html>



