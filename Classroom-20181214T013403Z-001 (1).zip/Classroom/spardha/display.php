<?php
	$url="localhost";
	$username = "root";
	$password="";
	$db="it146";
	$con = mysqli_connect($url,$username,$password,$db);
	if(!$con)
	{
		die("Unable to connect".mysqli_connect_error());
	}
	$sql="select * from student";
	$result = mysqli_query($con,$sql);
	if(mysqli_num_rows($result) > 0)
	{
	while($row = mysqli_fetch_assoc($result))
	{
		echo("id:".$row["id"]);
		echo("name:".$row["name"]);
		echo("branch:".$row["branch"]);
	}
	}
	else
	{
		echo("no row are available");
	}
	mysqli_close($con);
	?>