
<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name=" cps"; // Database name 
$tbl_name="registration"; // Table name

// Connect to server and select databse.
mysqli_connect("$host", "$username", "$password") or die(mysqli_error());
echo "Connected to MySQL<br />";
mysqli_select_db("$db_name") or die(mysqli_error());
echo "Connected to Database<br />";

// Define $username and $password 
$username=$_POST['username']; 
$password=$_POST['password'];



$sql="SELECT * FROM $tbl_name WHERE email='$username' and password='$password'";
$result=mysqli_query($sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);
// If result matched $username and $password, table row must be 1 row
if ($count==1) {
    echo "Success!";
} else {
    echo "Please enter valid details";
}


?>
