<?php
	$url="localhost";
	$username = "root";
	$password="";
	$db="cps";
	$r1=isset($_POST['r1']) ? $_POST['r1'] : '';
	$r2=isset($_POST['r2']) ? $_POST['r2'] : '';
	$r3=isset($_POST['r3']) ? $_POST['r3'] : '';
	$r4=isset($_POST['r4']) ? $_POST['r4'] : '';
    $message=isset($_POST['message']) ? $_POST['message'] : '';
	$con = mysqli_connect($url,$username,$password,$db);
	if(!$con)
	{
		die("Unable to connect".mysqli_connect_error());
	}
	$sql="insert into feedback(r1,r2,r3,r4,message) values('$r1','$r2','$r3','$r4','message')";
	if(mysqli_query($con,$sql))
	{
		echo("one row inserted");
	}
	else
	{
		echo("no row inserted".mysqli_error($con));
	}
	mysqli_close($con);
	?>