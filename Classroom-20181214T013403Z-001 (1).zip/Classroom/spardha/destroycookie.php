<?php
setcookie("user","",time()-60*60);
echo("cookie destroyed");
?>
