<?php
session_start();
if(isset($_SESSION["pc"]))
{
	$_SESSION["pc"]+=1;
}
else
{
	$_SESSION["pc"]=1;
}
echo("no of visitors:".$_SESSION["pc"]);
?>